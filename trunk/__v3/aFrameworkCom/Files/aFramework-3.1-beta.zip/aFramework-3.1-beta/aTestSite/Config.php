<?php
	Config::set('general.site_title',			'aTestSite');
	Config::set('general.site_tagline',			'This is just an example aFramework site.');
	Config::set('general.site_author',			'Some Dude');
	Config::set('general.contact_email',		'your@email.com');
	Config::set('general.default_style',		'clean');

	Config::set('db.user',						'root');
	Config::set('db.pass',						'root');
	Config::set('db.host',						'localhost');

	Config::set('admin.user',					'admin');
	Config::set('admin.pass',					'1234');
?>
