<?php return array(

# Routes.php
'url.add-page' => 'add-page', 

# NavigationModule.php
'Add Page +' => 'Add Page +', 

# PageModule.php
'Add a Page' => 'Add a Page', 

# PageAdmin.tpl.php
'The form contains errors.' => 'The form contains errors.', 
'Please make sure you have filled out everything correctly.' => 'Please make sure you have filled out everything correctly.', 
'Page Title' => 'Page Title', 
'Slug' => 'Slug', 
'Show in Navigation' => 'Show in Navigation', 
'Yes' => 'Yes', 
'No' => 'No', 
'Priority' => 'Priority', 
'A lower number places page early in the list' => 'A lower number places page early in the list', 
'Meta Keywords' => 'Meta Keywords', 
'Meta Description' => 'Meta Description', 
'Page Content' => 'Page Content', 
'Save Changes' => 'Save Changes', 
'Add Page' => 'Add Page', 
'or' => 'or', 
'Delete this Page' => 'Delete this Page', 

# BeforePageAdmin.tpl.php
'Edit Page' => 'Edit Page', 
'Add Page' => 'Add Page'

); ?>
