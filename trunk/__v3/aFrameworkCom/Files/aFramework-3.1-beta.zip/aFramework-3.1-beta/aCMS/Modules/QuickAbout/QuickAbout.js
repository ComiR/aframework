aFramework.modules.QuickAbout = {
	run: function () {		
		$('#quick-about textarea[name=content]').markItUp(mySettings);
	}
};
