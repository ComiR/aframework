<p>
	<?php echo Lang::get('No comments yet, why not'); ?> 
	<a href="#post-comment">
		<?php echo Lang::get('be the first to post one'); ?>
	</a>?
</p>
