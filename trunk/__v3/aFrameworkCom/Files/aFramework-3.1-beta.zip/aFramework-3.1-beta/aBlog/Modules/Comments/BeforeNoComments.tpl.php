<h3><?php echo Lang::get('No Comments'); ?></h3>
