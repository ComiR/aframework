<h2><?php echo escHTML($title); ?></h2>

<?php echo NiceString::makeNice($description, 3); ?>