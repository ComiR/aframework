<?php
	class aFramework_MostPopularContentModule {
		public static $tplVars = array();
		public static $tplFile = true;

		public static function run () {
			
		}
	}
?>