<h2><?php echo Lang::get('Change Style'); ?></h2>
