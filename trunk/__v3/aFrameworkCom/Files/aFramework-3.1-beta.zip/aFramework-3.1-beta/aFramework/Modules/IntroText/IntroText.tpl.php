<h2><?php echo escHTML($heading); ?></h2>

<?php echo NiceString::makeNice($content, 3); ?>