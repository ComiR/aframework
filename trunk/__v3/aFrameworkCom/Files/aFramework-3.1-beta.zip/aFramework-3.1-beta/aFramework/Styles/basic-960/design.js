(function () {
	$('#tertiary-content, #footer').fullPageWidthBar();
})();
