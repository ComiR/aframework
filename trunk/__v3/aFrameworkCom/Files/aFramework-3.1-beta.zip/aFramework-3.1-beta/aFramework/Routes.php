<?php
	return array(
		'/'										=> 'Home', 
		'/' . Lang::get('url.admin') . '/'		=> 'AdminLogin', 
		'/' . Lang::get('url.contact') . '/'	=> 'Contact', 
		'/' . Lang::get('url.search') . '/'		=> 'SearchResults', 
		'/' . Lang::get('url.styles') . '/'		=> 'Styles'
	);
?>
