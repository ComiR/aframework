<p>You were incorrectly referred to this page by: <strong><a href="<?php echo str_replace('&', '&amp;', $referrer); ?>"><?php echo $referrerSite; ?></a></strong>.</p>

<p>Perhaps you could try one of the following:</p>

<ul>
	<li>Go to the <a href="<?php echo Router::urlFor('Home'); ?>">homepage</a> and try to navigate your way from there</li>
	<li>Try the <a href="<?php echo Router::urlFor('Sitemap'); ?>">sitemap</a></li>
</ul>