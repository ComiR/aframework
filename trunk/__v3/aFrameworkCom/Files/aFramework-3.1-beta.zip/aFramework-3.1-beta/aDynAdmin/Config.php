<?php
	Config::set('adynadmin',					array(
													'title'			=> 'aDynAdmin', 
													'description'	=> 'Settings for aFramework\'s dynamic admin; aDynAdmin'
												));
	Config::set('adynadmin.num_items_per_page',	10);
	Config::set('general.site_title',			'aDynAdmin');
	Config::set('general.site_tagline',			'A Dynamic MySQL Database Admin.');
?>
