<?php return array(

# Routes.php
'url.dynadmin' => 'dynadmin', 

# DynItem.tpl.php
'Save' => 'Save', 
'Add' => 'Add', 

# BeforeDynItem.tpl.php
'Edit' => 'Edit', 
'Add' => 'Add', 

# DynNavModule.php
'Browse' => 'Browse', 
'Add' => 'Add', 
'Edit' => 'Edit', 

# RecentDynItems.tpl.php
'new' => 'new', 

# BeforeRecentDynItems.tpl.php
"What's New" => "What's New", 

# DynTables.tpl.php
'Home' => 'Home', 
'Config' => 'Config', 
'Tools' => 'Tools', 

# NoItems.tpl.php
"It appears you don't have any" => "It appears you don't have any", 
'yet, why not' => 'yet, why not', 
'add some' => 'add some', 

# AfterDynItems.tpl.php
'Previous' => 'Previous', 
'Next' => 'Next', 

# DynItems.tpl.php
'Edit' => 'Edit', 
'Delete' => 'Delete'

); ?>
