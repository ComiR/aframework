<?php return array(

# Routes.php
'url.dynadmin' => 'dynadmin', 

# DynItem.tpl.php
'Save' => 'Spara', 
'Add' => 'Lägg till', 

# BeforeDynItem.tpl.php
'Edit' => 'Redigera', 

# DynNavModule.php
'Browse' => 'Bläddra', 

# RecentDynItems.tpl.php
'new' => 'ny', 

# BeforeRecentDynItems.tpl.php
"What's New" => "Det senaste", 

# DynTables.tpl.php
'Home' => 'Hem', 
'Config' => 'Konfiguration', 
'Tools' => 'Verktyg', 

# NoItems.tpl.php
"It appears you don't have any" => "Du verkar inte ha några", 
'yet, why not' => 'än, varför inte', 
'add some' => 'lägga till några', 

# AfterDynItems.tpl.php
'Previous' => 'Föregående', 
'Next' => 'Nästa', 

# DynItems.tpl.php
'Delete' => 'Radera'

); ?>
