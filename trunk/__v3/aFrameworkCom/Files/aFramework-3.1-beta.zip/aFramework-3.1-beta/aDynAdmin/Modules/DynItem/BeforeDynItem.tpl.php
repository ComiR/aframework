<h2><?php echo $edit_or_add . ' ' . $singular_table_name; ?></h2>
