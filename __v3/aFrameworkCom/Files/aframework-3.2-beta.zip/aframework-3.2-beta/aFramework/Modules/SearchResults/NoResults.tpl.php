<h3><?php echo Lang::get('Suggestions'); ?></h3>

<ul>
	<li><?php echo Lang::get('Make sure all your words are spelled correctly'); ?></li>
	<li><?php echo Lang::get('Try different keywords'); ?></li>
	<li><?php echo Lang::get('Try more general keywords'); ?></li>
</ul>

<p><?php echo Lang::get('Happy hunting!'); ?></p>