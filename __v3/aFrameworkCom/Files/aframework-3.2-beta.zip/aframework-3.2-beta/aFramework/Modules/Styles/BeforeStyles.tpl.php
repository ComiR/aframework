<h2><?php echo Lang::get('Styles'); ?></h2>

<p>
	<?php echo Lang::get('There are currently'); ?> 
	<?php echo count($styles); ?> 
	<?php echo Lang::get('styles to choose from.'); ?>
</p>
