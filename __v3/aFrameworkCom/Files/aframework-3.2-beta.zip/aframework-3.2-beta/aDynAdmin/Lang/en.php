<?php return array(

# Routes.php
'url.dynadmin' => 'dynadmin', 

# DynItem.tpl.php
'Save' => 'Save', 
'Add' => 'Add', 

# DynItemModule.php
'Edit' => 'Edit', 

# DynNavModule.php
'Browse' => 'Browse', 

# RecentDynItems.tpl.php
'new' => 'new', 

# DynTables.tpl.php
'Home' => 'Home', 
'Config' => 'Config', 
'Tools' => 'Tools', 

# NoItems.tpl.php
'yet, why not' => 'yet, why not', 
'add some' => 'add some', 

# AfterDynItems.tpl.php
'Previous' => 'Previous', 
'Next' => 'Next', 

# DynItems.tpl.php
'Delete' => 'Delete'

); ?>
