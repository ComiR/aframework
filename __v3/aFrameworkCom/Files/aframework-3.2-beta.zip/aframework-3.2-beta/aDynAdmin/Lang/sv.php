<?php return array(

# Routes.php
'url.dynadmin' => 'dynadmin', 

# DynItem.tpl.php
'Save' => 'Spara', 
'Add' => 'Lägg till', 

# DynItemModule.php
'Edit' => 'Redigera', 

# DynNavModule.php
'Browse' => 'Bläddra', 

# RecentDynItems.tpl.php
'new' => 'ny', 

# DynTables.tpl.php
'Home' => 'Hem', 
'Config' => 'Konfiguration', 
'Tools' => 'Verktyg', 

# NoItems.tpl.php
'yet, why not' => 'än, varför inte', 
'add some' => 'lägga till några', 

# AfterDynItems.tpl.php
'Previous' => 'Föregående', 
'Next' => 'Nästa', 

# DynItems.tpl.php
'Delete' => 'Radera'

); ?>
