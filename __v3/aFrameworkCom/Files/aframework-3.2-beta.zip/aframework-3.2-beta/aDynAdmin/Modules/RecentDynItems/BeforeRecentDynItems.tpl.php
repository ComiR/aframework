<h2><?php echo Lang::get("What's New"); ?></h2>
