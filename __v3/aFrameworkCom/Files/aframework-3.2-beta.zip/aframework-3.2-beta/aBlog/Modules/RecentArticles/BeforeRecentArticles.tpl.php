<h2><?php echo Lang::get('Recent Articles'); ?></h2>
