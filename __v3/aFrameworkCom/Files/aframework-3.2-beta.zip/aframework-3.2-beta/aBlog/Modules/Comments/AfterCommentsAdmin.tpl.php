<?php if (SU) { ?>
	<form method="post" action="">

		<p>
			<input type="hidden" name="articles_id" value="<?php echo $articles_id; ?>"/>
			<input type="submit" name="comments_delete_all_spam" value="<?php echo Lang::get('Delete all Spam Comments'); ?>"/>
		</p>

	</form>
<?php } ?>
