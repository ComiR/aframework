<h2>Random Image</h2>

<p>
	<a href="<?php echo $image['src']; ?>">
		<img src="<?php echo $image['src']; ?>" alt=""/>
	</a>
</p>
