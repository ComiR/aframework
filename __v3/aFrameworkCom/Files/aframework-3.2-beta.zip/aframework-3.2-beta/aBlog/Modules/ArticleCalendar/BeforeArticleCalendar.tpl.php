<h2>
	<a href="<?php echo $selected_month['url']; ?>">
		<?php echo escHTML($selected_month['title']); ?>
	</a>
</h2>
