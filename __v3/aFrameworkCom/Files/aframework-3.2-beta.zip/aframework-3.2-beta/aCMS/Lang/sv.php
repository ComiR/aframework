<?php return array(

# Routes.php
'url.add-page' => 'lagg-till-sida', 

# DebugModule.php
'Add Page +' => 'Lägg till sida +', 

# IntroTextAdmin.tpl.php
'Introductionary Text' => 'Introduktionstext', 
'Save Changes' => 'Spara ändringar', 

# QuickAboutAdmin.tpl.php
'Short Description of' => 'Kort beskrivning av', 

# Page.js
'Advanced View' => 'Avancerad vy', 
'Are you sure?' => 'Är du säker?', 

# PageModule.php
'Add a Page' => 'Lägg till en sida', 

# PageAdmin.tpl.php
'The form contains errors.' => 'Formuläret innehåller fel.', 
'Please make sure you have filled out everything correctly.' => 'Vänligen kontrollera att alla fält är korrekt ifyllda.', 
'Page Title' => 'Sidtitel', 
'Slug' => 'Slug', 
'Show in Navigation' => 'Visa i navigationen', 
'Yes' => 'Ja', 
'No' => 'Nej', 
'Priority' => 'Prioritet', 
'A lower number places page early in the list' => 'Ett lägre nummer placerar sidan tidigt i listan', 
'Meta Keywords' => 'Meta keywords', 
'Meta Description' => 'Meta description', 
'Page Content' => 'Sidinnehåll', 
'Add Page' => 'Lägg till sida', 
'or' => 'eller', 
'Delete this Page' => 'Ta bort sidan', 

# BeforePageAdmin.tpl.php
'Edit Page' => 'Redigera sida'

); ?>
