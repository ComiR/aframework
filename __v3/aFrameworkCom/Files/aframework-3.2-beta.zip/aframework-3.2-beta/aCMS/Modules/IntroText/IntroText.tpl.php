<?php echo NiceString::makeNice($page['content'], 2, false, false, true); ?>
