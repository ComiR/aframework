<?php echo NiceString::makeNice($content, 2, false, false, true); ?>
