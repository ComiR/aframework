<h3><?php echo Lang::get('Post a Comment'); ?></h3>
