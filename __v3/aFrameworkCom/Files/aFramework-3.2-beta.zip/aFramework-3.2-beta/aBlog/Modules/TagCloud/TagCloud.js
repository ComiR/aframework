aFramework.modules.TagCloud = {
	run: function () {
		$('#tag-cloud').tagSizes('strong');
	}
};