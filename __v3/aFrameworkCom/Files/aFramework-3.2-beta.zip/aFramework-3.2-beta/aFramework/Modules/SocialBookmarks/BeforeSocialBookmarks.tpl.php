<h2><?php echo Lang::get('Bookmark this URL'); ?></h2>

<p><?php echo Lang::get('Add this URL to your favourite bookmarking service.'); ?></p>