<?php
	Config::set('general.site_title',			'aCMS');
	Config::set('general.site_tagline',			'Just another Content Management System.');
?>
