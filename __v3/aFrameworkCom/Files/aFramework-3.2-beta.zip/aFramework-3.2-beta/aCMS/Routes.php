<?php
	return array(
		'/' . Lang::get('url.add-page') . '/'	=> 'AddPage', 
		'/:url_str/'							=> 'Page'
	);
?>
