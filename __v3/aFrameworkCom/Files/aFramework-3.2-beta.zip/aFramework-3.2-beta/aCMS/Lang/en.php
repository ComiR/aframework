<?php return array(

# Routes.php
'url.add-page' => 'add-page', 

# DebugModule.php
'Add Page +' => 'Add Page +', 

# IntroTextAdmin.tpl.php
'Introductionary Text' => 'Introductionary Text', 
'Save Changes' => 'Save Changes', 

# QuickAboutAdmin.tpl.php
'Short Description of' => 'Short Description of', 

# Page.js
'Advanced View' => 'Advanced View', 
'Are you sure?' => 'Are you sure?', 

# PageModule.php
'Add a Page' => 'Add a Page', 

# PageAdmin.tpl.php
'The form contains errors.' => 'The form contains errors.', 
'Please make sure you have filled out everything correctly.' => 'Please make sure you have filled out everything correctly.', 
'Page Title' => 'Page Title', 
'Slug' => 'Slug', 
'Show in Navigation' => 'Show in Navigation', 
'Yes' => 'Yes', 
'No' => 'No', 
'Priority' => 'Priority', 
'A lower number places page early in the list' => 'A lower number places page early in the list', 
'Meta Keywords' => 'Meta Keywords', 
'Meta Description' => 'Meta Description', 
'Page Content' => 'Page Content', 
'Add Page' => 'Add Page', 
'or' => 'or', 
'Delete this Page' => 'Delete this Page', 

# BeforePageAdmin.tpl.php
'Edit Page' => 'Edit Page'

); ?>
