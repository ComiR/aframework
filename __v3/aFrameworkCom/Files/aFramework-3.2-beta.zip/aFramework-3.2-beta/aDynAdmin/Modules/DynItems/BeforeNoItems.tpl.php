<h2><?php echo escHTML($table['title']); ?></h2>
